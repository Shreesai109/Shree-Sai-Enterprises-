# Shree Sai Employee — mobile cloud-build starter

This package is set up for a cloud build using Codemagic. It creates the missing Android/Web platform scaffolding during the build.

## Build from an Android phone
1. Extract this ZIP on your phone.
2. Create a private GitHub repository at https://github.com/new .
3. Upload the files and folder from this ZIP into the repository root: `pubspec.yaml`, `codemagic.yaml`, and the `lib` folder containing `main.dart`.
4. Sign up at https://codemagic.io/ and connect GitHub.
5. Add the repository as an app; choose Flutter if prompted.
6. Start the workflow named `Shree Sai Employee Android APK`.
7. When the build finishes successfully, open Artifacts and download the APK.

If Codemagic does not automatically detect the YAML workflow, check its workflow configuration documentation and ensure `codemagic.yaml` is at the repository root.

## Important limitations
This is a starter/demo APK only. It is not ready for company-wide attendance:
- Employee/Admin authentication and role permissions are not connected.
- No shared cloud database, admin dashboard, or leave approval is implemented.
- Office coordinates are intentionally set to 0.0 and must be replaced with verified coordinates for the actual office entrance near Jupiter Hospital.
- GPS checks alone are not anti-fraud protection.
- The debug APK is for testing only; production distribution requires release signing and security review.
