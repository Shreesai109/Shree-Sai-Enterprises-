import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

void main() {
  runApp(const ShreeSaiEmployeeApp());
}

class ShreeSaiEmployeeApp extends StatelessWidget {
  const ShreeSaiEmployeeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Shree Sai Employee',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF145DA0)),
        useMaterial3: true,
      ),
      home: const EmployeeHomePage(),
    );
  }
}

class EmployeeHomePage extends StatefulWidget {
  const EmployeeHomePage({super.key});

  @override
  State<EmployeeHomePage> createState() => _EmployeeHomePageState();
}

class _EmployeeHomePageState extends State<EmployeeHomePage> {
  // TODO: Replace with the verified latitude/longitude for your exact office entrance.
  // Do not guess coordinates: confirm the exact site in Google Maps first.
  static const double officeLatitude = 0.0;
  static const double officeLongitude = 0.0;
  static const double allowedRadiusMeters = 100;

  bool checkedIn = false;
  DateTime? checkInTime;
  String status = 'Please sign in with your company account to begin.';
  bool busy = false;

  Future<void> markAttendance() async {
    if (busy) return;
    setState(() => busy = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() => status = 'Please turn on Location Services and try again.');
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() => status = 'Location permission is required for GPS attendance.');
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
          timeLimit: Duration(seconds: 20),
        ),
      );

      // Attendance is blocked until a real office coordinate is configured.
      if (officeLatitude == 0.0 && officeLongitude == 0.0) {
        setState(() {
          status = 'GPS detected (${position.latitude.toStringAsFixed(5)}, '
              '${position.longitude.toStringAsFixed(5)}), but the office coordinates '
              'are not configured yet. Ask the app administrator to set them.';
        });
        return;
      }

      final distance = Geolocator.distanceBetween(
        position.latitude,
        position.longitude,
        officeLatitude,
        officeLongitude,
      );

      if (distance > allowedRadiusMeters) {
        setState(() {
          status = 'You are about ${distance.round()} m from the office. '
              'Attendance is allowed only within ${allowedRadiusMeters.round()} m.';
        });
        return;
      }

      final now = DateTime.now();
      setState(() {
        if (!checkedIn) {
          checkedIn = true;
          checkInTime = now;
          status = 'Check-in recorded locally at ${_formatTime(now)}. '
              'Cloud saving is not connected yet.';
        } else {
          checkedIn = false;
          status = 'Check-out recorded locally at ${_formatTime(now)}. '
              'Cloud saving is not connected yet.';
          checkInTime = null;
        }
      });
    } catch (e) {
      setState(() => status = 'Could not get GPS location. Please try again. ($e)');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _formatTime(DateTime value) {
    final h = value.hour.toString().padLeft(2, '0');
    final m = value.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  void showLeaveDialog() {
    final reasonController = TextEditingController();
    DateTime selectedDate = DateTime.now().add(const Duration(days: 1));

    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Apply for leave'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Select your leave date in the next version.'),
            const SizedBox(height: 12),
            TextField(
              controller: reasonController,
              decoration: const InputDecoration(
                labelText: 'Reason for leave',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(reasonController.text.trim().isEmpty
                      ? 'Leave form demo only: connect database before use.'
                      : 'Leave request demo only: "${reasonController.text.trim()}"'),
                ),
              );
            },
            child: const Text('Submit demo'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shree Sai Employee'),
        actions: [
          IconButton(
            tooltip: 'Profile (demo)',
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Employee login is not connected yet.')),
            ),
            icon: const Icon(Icons.account_circle_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Welcome to Shree Sai Enterprises',
                      style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  const Text('Employee attendance • Office timing • Leave requests'),
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: busy ? null : markAttendance,
                      icon: Icon(checkedIn ? Icons.logout : Icons.login),
                      label: Text(busy
                          ? 'Checking GPS…'
                          : checkedIn
                              ? 'Check Out'
                              : 'Check In with GPS'),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(status),
                  if (checkInTime != null) ...[
                    const SizedBox(height: 8),
                    Text('Today’s check-in: ${_formatTime(checkInTime!)}'),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.schedule),
              title: const Text('Office timing'),
              subtitle: const Text('To be configured by Admin'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Office timing settings are not configured yet.')),
              ),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.event_available),
              title: const Text('Apply for leave'),
              subtitle: const Text('Create a leave request (demo only)'),
              trailing: const Icon(Icons.chevron_right),
              onTap: showLeaveDialog,
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'DEVELOPMENT STARTER — not production-ready. Login, admin permissions, '
            'cloud database, server-side attendance validation and audit logs must be '
            'implemented before company-wide use.',
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }
}
